<?php

   include "dbconfig.php";
   
   $input=json_decode(file_get_contents("php://input"),true);
   
   $fullName=$input["fullName"];
   $phoneNo=$input["phoneNo"];
   $pincode=$input["pincode"];
   $address=$input["address"];
   $userAge=$input["userAge"];

   $battAge1=$input["battAge1"];
   $battAge2=$input["battAge2"];
   $battAge3=$input["battAge3"];
   $battAge4=$input["battAge4"];

   $tokon=$input["tokon"];

   $qury="SELECT * From Product WHERE utokon='$tokon'";
   $result=mysqli_query($conn, $qury);

   if(mysqli_num_rows($result)>0){
       $row=mysqli_fetch_array($result, MYSQLI_NUM);
       if($row[4]==1){
           date_default_timezone_set("Asia/Kolkata");
           $dateTime=date("Y-m-d H:i:s");
           
           $qury="INSERT INTO User (uPhoneNo,utokon,name,address,pinc,usreage,batage1,batage2,batage3,batage4,regdate) VALUES ('$phoneNo','$tokon','$fullName','$address','$pincode','$userAge','$battAge1','$battAge2','$battAge3','$battAge4','$dateTime')";
           $result=mysqli_query($conn, $qury);

           $qury="UPDATE Product SET status='2',uPhoneNo='$phoneNo',usedate='$dateTime' WHERE utokon='$tokon'";
           $result=mysqli_query($conn, $qury);

           $qury="CREATE TABLE $tokon(date DATE,time TIME,batt1 VARCHAR(10),batt2 VARCHAR(10),batt3 VARCHAR(10),batt4 VARCHAR(10),totalv VARCHAR(10))";

           $servername="revms-database.cbknx3byi7qy.ap-south-1.rds.amazonaws.com";
           $username="root";
           $password="nITISH#9734590605n";
           $databname="UserTable";
           $connNew=mysqli_connect($servername, $username, $password, $databname);
           $result=mysqli_query($connNew, $qury);

           echo $result;

           $response['error']="000";
           $response['value']="Ok Code";

       }elseif($row[4]==0){
           $response['error']="002";
           $response['value']="Invalid Code";

       }else{
           $response['error']="003";
           $response['value']="Alrady Uesed";
       }

   }else{
       $response['error']="001";
       $response['value']="Invalid Code";
   }

   echo json_encode($response);

?>