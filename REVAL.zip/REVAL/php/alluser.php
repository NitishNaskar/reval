<?php

 include "dbconfig.php";

    $qury="SELECT name,uPhoneNo From User";

    $result=mysqli_query($conn, $qury);

    if (mysqli_num_rows($result)>0) {
        while($row =mysqli_fetch_assoc($result)){
         
            echo " 
            <tr>
            <td>
                        <img class='avatar rounded-circle' src='assets/images/xs/avatar11.jpg' alt=''>
                        <span class='fw-bold ms-1'>{$row["name"]}</span>
                    </td>
                    
                    <td>{$row["uPhoneNo"]}</td>
          
                    <td>
                        <div class='btn-group' role='group' aria-label='Basic outlined example'>
                            <button type='button' class='btn btn-outline-secondary' onclick='passPhoneNo({$row["uPhoneNo"]})'><i class='icofont-eye-alt text-success'></i></button>
                            <button type='button' class='btn btn-outline-secondary deleterow'><i class='icofont-ui-delete text-danger'></i></button>
                        </div>
                    </td>
                    
                    <tr>";
        }

    }
?>