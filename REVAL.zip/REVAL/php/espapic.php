<?php
   
  $servername="revms-database.cbknx3byi7qy.ap-south-1.rds.amazonaws.com";
  $username="root";
  $password="nITISH#9734590605n";
  $databname="UserTable";
   
  $conn=mysqli_connect($servername,$username,$password,$databname);

  $user="";
  $datee="";
  $timee="";
  $batt1="";
  $batt2="";
  $batt3="";
  $batt4="";
  $current="";
   

  if($_SERVER["REQUEST_METHOD"]=="POST"){
    $user = test_input($_POST["uuid"]);
    $batt1 = test_input($_POST["batt1"]);
    $batt2 = test_input($_POST["batt2"]);
    $batt3 = test_input($_POST["batt3"]);
    $batt4 = test_input($_POST["batt4"]);
    $datee= test_input($_POST["datee"]);
    $timee= test_input($_POST["timee"]);
    $current= test_input($_POST["cou"]);
    
    $sql = "INSERT INTO $user (date,time,batt1,batt2,batt3,batt4,current)
    VALUES ('$datee','$timee',$batt1,$batt2,$batt3,$batt4,$current)";
    
  if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}
else {
    echo "No data posted with HTTP POST.";
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>