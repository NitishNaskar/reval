<?php 

$servername="revms-database.cbknx3byi7qy.ap-south-1.rds.amazonaws.com";
$username="root";
$password="nITISH#9734590605n";
$databname="UserTable";
$conn=new mysqli ($servername,$username,$password,$databname);

$datee=$_POST["datee"];
$ProductID=$_POST["ProductID"];

$sql = "SELECT * FROM $ProductID where date='$datee' ORDER BY time DESC";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) >0){
  $row=mysqli_fetch_all($result);
  echo json_encode($row);
}else{
  echo json_encode("NULL");
}
?>