<?php

   include "dbconfig.php";

   $phoneNo=$_POST["phoneNo"];

   $qury="SELECT * From User WHERE uPhoneNo=$phoneNo";
   $result=mysqli_query($conn, $qury);

   $row = mysqli_fetch_array($result, MYSQLI_NUM);
   $myJSON = json_encode($row);
   echo $myJSON;

?>