<?php

    $servername="revms-database.cbknx3byi7qy.ap-south-1.rds.amazonaws.com";
    $username="root";
    $password="nITISH#9734590605n";
    $databname="Revms";

    $conn=mysqli_connect($servername, $username, $password, $databname);
    
?>