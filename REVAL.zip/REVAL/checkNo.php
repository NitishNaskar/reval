<?php

  include "dbconfig.php";

  $phoneNo=$_POST["phone"];
  $usersql="SELECT uPhoneNo From User where uPhoneNo='$phoneNo'";
  
  $result=mysqli_query($conn, $usersql);
  $row=mysqli_num_rows($result);
  
  if($row>0){
    $response['error']="000";
    $response['value']="True";
  }else{
    $response['error']="001";
    $response['value']="False";
  }

  echo json_encode($response);

?>